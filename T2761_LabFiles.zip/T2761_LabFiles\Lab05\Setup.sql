/*
Lab setup file T2761 Module 5

Dependencies: 
AdventureworksLT database
*/

SET NOCOUNT ON
USE AdventureworksLT
GO

-------------------------------------------------------------------------------
--Ex1
--The proc to be executed in ex1

CREATE OR ALTER PROC GetCustomersCountry
@City nvarchar(60)
AS
SELECT 
 c.CustomerID
,c.FirstName
,c.LastName
,c.CompanyName
,c.Phone
,a.City
,a.CountryRegion
FROM SalesLT.Customer AS c
INNER JOIN SalesLT.CustomerAddress AS ca ON ca.CustomerID = c.CustomerID
INNER JOIN SalesLT.Address AS a ON a.AddressID = ca.AddressID
WHERE a.City = @City
ORDER BY CompanyName, City
GO
-------------------------------------------------------------------------------





PRINT ''
PRINT ''
PRINT ''
PRINT 'Done !!!'

