/*
Lab setup file T2761 Module 6

Dependencies: 
AdventureworksLT database
*/

SET NOCOUNT ON
USE AdventureworksLT
GO

-------------------------------------------------------------------------------
--Ex1
CREATE OR ALTER PROC GetExpensiveProducts
@ListPrice money
AS
SELECT p.Name, p.ListPrice, p.Color
FROM SalesLT.Product AS p
WHERE p.ListPrice > @ListPrice
ORDER BY ListPrice
GO
-------------------------------------------------------------------------------





PRINT ''
PRINT ''
PRINT ''
PRINT 'Done !!!'

