/*
Lab setup file T2761 Module 2, Set operators

Dependencies: 
AdventureworksLT database
*/

SET NOCOUNT ON
USE AdventureworksLT

-------------------------------------------------------------------------------
--Ex1
--The yearly Products tables

DROP TABLE IF EXISTS Product2002
DROP TABLE IF EXISTS Product2005
DROP TABLE IF EXISTS Product2006
DROP TABLE IF EXISTS Product2007

SELECT *
INTO dbo.Product2002
FROM SalesLT.Product
WHERE SellStartDate >= '2002-01-01T00:00:00' AND SellStartDate < '2003-01-01T00:00:00'

SELECT *
INTO dbo.Product2005
FROM SalesLT.Product
WHERE SellStartDate >= '2005-01-01T00:00:00' AND SellStartDate < '2006-01-01T00:00:00'

SELECT *
INTO dbo.Product2006
FROM SalesLT.Product
WHERE SellStartDate >= '2006-01-01T00:00:00' AND SellStartDate < '2007-01-01T00:00:00'

SELECT *
INTO dbo.Product2007
FROM SalesLT.Product
WHERE SellStartDate >= '2007-01-01T00:00:00' AND SellStartDate < '2008-01-01T00:00:00'
GO
-------------------------------------------------------------------------------


-------------------------------------------------------------------------------
--Ex2
--3 most recent orders containg some specific product
CREATE OR ALTER FUNCTION dbo.RecentordersIncludingProduct(@ProductID int)
RETURNS table
AS
RETURN(
 SELECT TOP(3) h.SalesOrderID, h.OrderDate, h.CustomerID, h.SubTotal, h.TaxAmt, h.Freight
 FROM SalesLT.SalesOrderHeader AS h
 WHERE 
 EXISTS(
	SELECT * 
	FROM SalesLT.SalesOrderDetail AS d 
	WHERE d.SalesOrderID = h.SalesOrderID AND d.ProductID = @ProductID
	)
 ORDER BY OrderDate DESC
)
GO

PRINT ''
PRINT ''
PRINT ''
PRINT 'Done !!!'

