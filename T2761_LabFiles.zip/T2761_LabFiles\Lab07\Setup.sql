/*
Lab setup file T2761 Module 7

Dependencies: 
AdventureworksLT database
*/

SET NOCOUNT ON
USE AdventureworksLT
GO

-------------------------------------------------------------------------------
--Ex1
CREATE OR ALTER PROC GetExpensiveProducts
@ListPrice money = NULL
AS
IF @ListPrice IS NULL
  BEGIN
    PRINT 'You need to pass the price limit to this procedure'
	RETURN
  END
SELECT p.Name, p.ListPrice, p.Color
FROM SalesLT.Product AS p
WHERE p.ListPrice > @ListPrice
ORDER BY ListPrice
GO
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
--Ex3
ALTER TABLE SalesLT.SalesOrderDetail NOCHECK CONSTRAINT CK_SalesOrderDetail_OrderQty
GO

UPDATE SalesLT.SalesOrderDetail
SET OrderQty = 0
WHERE SalesOrderID = 71783	AND SalesOrderDetailID = 110749
GO

CREATE OR ALTER PROCEDURE ProductsInOrders
@Color varchar(30)
AS
SELECT p.Name AS ProductName, SUM(h.TotalDue / (d.OrderQty * d.UnitPrice)) AS PartOfTotalOrder
FROM SalesLT.SalesOrderHeader AS h 
INNER JOIN SalesLT.SalesOrderDetail AS d ON d.SalesOrderID = h.SalesOrderID
INNER JOIN SalesLT.Product AS p ON p.ProductID = d.ProductID
WHERE p.Color = @Color
GROUP BY p.Name
GO
-------------------------------------------------------------------------------





PRINT ''
PRINT ''
PRINT ''
PRINT 'Done !!!'

