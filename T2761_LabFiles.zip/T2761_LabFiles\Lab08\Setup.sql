/*
Lab setup file T2761 Module 8

Dependencies: 
AdventureworksLT database
*/

SET NOCOUNT ON
USE AdventureworksLT
GO

-------------------------------------------------------------------------------
--Ex2

CREATE OR ALTER PROC dbo.AddOrder
AS
DECLARE @SalesOrderID int

INSERT INTO SalesLT.SalesOrderHeader
(RevisionNumber, OrderDate, DueDate, ShipDate, Status,OnlineOrderFlag
,PurchaseOrderNumber, AccountNumber, CustomerID, ShipToAddressID
,BillToAddressID, ShipMethod, CreditCardApprovalCode, SubTotal, TaxAmt, Freight
,Comment, rowguid, ModifiedDate)
VALUES
(2, GETDATE(), DATEADD(DAY, 30, GETDATE()), DATEADD(DAY, 5, GETDATE())
,5, 0, 'PO5536545166', '10-4020-000277'
,29638, 989, 989, 'CARGO TRANSPORT 5', NULL
,2137.231, 170.9785, 53.4308
,NULL, NEWID(), GETDATE())

SET @SalesOrderID = SCOPE_IDENTITY()

INSERT INTO SalesLT.SalesOrderDetail
(SalesOrderID, OrderQty ,ProductID, UnitPrice, UnitPriceDiscount, rowguid, ModifiedDate)
VALUES(@SalesOrderID, 5, 982, 461.00, 0 ,NEWID(), GETDATE())

INSERT INTO SalesLT.SalesOrderDetail
(SalesOrderID, OrderQty ,ProductID, UnitPrice, UnitPriceDiscount, rowguid, ModifiedDate)
VALUES(@SalesOrderID, 2, 822, 356.00, 0 ,NEWID(), GETDATE())

GO
-------------------------------------------------------------------------------





PRINT ''
PRINT ''
PRINT ''
PRINT 'Done !!!'

