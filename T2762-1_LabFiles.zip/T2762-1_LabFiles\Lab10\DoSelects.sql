-------------------------------------------------
--Prepare
-------------------------------------------------
IF @@TRANCOUNT > 0
 ROLLBACK
GO

SET NOCOUNT ON
USE AdventureWorks
GO

DROP TABLE IF EXISTS ImWorking
CREATE TABLE ImWorking(c1 int)
GO


DECLARE 
 @iterations bigint = 0
,@avgPrice money
,@msg varchar(50)

WHILE 1 = 1
BEGIN

	--Produce some output, for every 100 SELECT that we do
	IF @iterations%100 = 0
	BEGIN
		SET @msg = CONCAT('We''ve done ', @iterations, ' SELECTs')
		RAISERROR(@msg, 10, 1) WITH NOWAIT
	END

	IF OBJECT_ID('ImWorking') IS NULL
		BEGIN
			BREAK
		END
	ELSE
		BEGIN
			SET @iterations += 1
			SET @avgPrice = (SELECT AVG(ListPrice) FROM Production.Product WHERE Color = 'Yellow')
		END
END

SET @msg = CONCAT('We did ', @iterations, ' SELECTs in total')
SELECT @msg AS how_many_did_we_do
