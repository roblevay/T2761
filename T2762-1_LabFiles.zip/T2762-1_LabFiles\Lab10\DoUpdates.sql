-------------------------------------------------
--Prepare
-------------------------------------------------
IF @@TRANCOUNT > 0
 ROLLBACK
GO

SET NOCOUNT ON
USE AdventureWorks
GO

DROP TABLE IF EXISTS ImWorking
CREATE TABLE ImWorking(c1 int)
GO

DECLARE 
 @i int = 1
,@iterations_to_do int = 60
,@msg varchar(50)

WHILE @i < @iterations_to_do
BEGIN
	SET @i += 1

	--Produce some output, for every 5 UPDATE that we do
	IF @i%5 = 0
	BEGIN
		SET @msg = CONCAT('We''ve done ', @i, ' out of ', @iterations_to_do, ' UPDATEs')
		RAISERROR(@msg, 10, 1) WITH NOWAIT
	END

	BEGIN TRAN
	IF @i%2 = 0
		UPDATE Production.Product SET ListPrice = ListPrice * 1.1 WHERE ProductID = 834
	ELSE
		UPDATE Production.Product SET ListPrice = ListPrice * 0.9 WHERE ProductID = 834
	WAITFOR DELAY '00:00:01' --Pause 1 second
	COMMIT --No error handling etc., this is not production code!
END
--594,83


DROP TABLE IF EXISTS ImWorking
RAISERROR('Done!', 10, 1) WITH NOWAIT
